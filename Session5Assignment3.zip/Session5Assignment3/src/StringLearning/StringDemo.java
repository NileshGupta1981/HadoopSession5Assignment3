package StringLearning;
import java.io.IOException;
import java.util.ArrayList;
//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.Text;
//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.fs.Path;
//import org.apache.hadoop.mapreduce.Job;
//import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.Reducer;

public class StringDemo {

	public static void main (String args[]) throws Exception
	{
	String str="Hadoop is open source framework, Hadoop is good framework for handling big data";
		//Configuration conf = new Configuration();
	//Job job = new Job (conf , "String Learnign");
	//job.setJarByClass(StringDemo.class);
	//job.setMapperClass (Map.class);
	//job.setReducerClass(Reduce.class);
	//job.setOutputKeyClass(IntWritable.class);
	//job.setOutputValueClass(IntWritable.class);
	int count=0;
	ArrayList al = new ArrayList();
	String[] spacedelimiter = str.toString().split(" ");
	for ( int i=0; i < spacedelimiter.length;i++)
	{
		if (spacedelimiter[i].equals("Hadoop"))
		{
			count = count+1;
			
		} 
	}
	
	System.out.println("The Hadoop Word Codunt is "+ count);
	System.out.println("The updated string is ");
	System.out.println (str.replaceAll(","," " ));
	
	System.out.println("Initial Size of al:"+ al.size());
	al.add(str);
	System.out.println("After addition Size of al:"+al.size());
	System.out.println("Contents of al: "+ al);
	//String newstring = args[0].replaceAll(",", " ") ;
	
	
	
	}
	
}
